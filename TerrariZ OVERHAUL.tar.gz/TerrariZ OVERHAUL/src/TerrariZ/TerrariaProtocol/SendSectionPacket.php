<?php

namespace TerrariZ\TerrariaProtocol;

use TerrariZ\Server;
use TerrariZ\World\World;
use TerrariZ\Utils\Logger;

class SendSectionPacket
{
    public static function build(
        World $world,
        int $startX,
        int $startY,
        int $width,
        int $height,
        bool $compressed = true
    ): string {
        return $world->buildSectionPacket(
            $startX,
            $startY,
            $width,
            $height,
            $compressed
        );
    }
}
