<?php
namespace TerrariZ\TerrariaProtocol;

use TerrariZ\Server;
use TerrariZ\Utils\Logger;

class EssentialTilesPacket implements PacketInterface
{
    public const PACKET_ID = 8;

    public function handle(array $data, $clientSocket, Server $server): void
    {
        $pkt = new Packet($data['data']);

        try {
            $spawnX = $pkt->readInt32();
            $spawnY = $pkt->readInt32();

            $player = $server->getPlayerBySocket($clientSocket);
            if (!$player) return;

            if ($player->hasReceivedWorld()) return;
            $player->setReceivedWorld(true);

            $world  = $server->getWorld();
            $width  = $world->width;
            $height = $world->height;

            $secW = 200;
            $secH = 150;

            // disable PHP write buffering
            stream_set_write_buffer($clientSocket, 0);

            // build ordered sections (spawn-first)
            $sections = [];

            for ($sx = 0; $sx < $width; $sx += $secW) {
                for ($sy = 0; $sy < $height; $sy += $secH) {

                    $cx = $sx + 100;
                    $cy = $sy + 75;

                    $dist = abs($cx - $spawnX) + abs($cy - $spawnY);

                    $sections[] = [$sx, $sy, $dist];
                }
            }

            usort($sections, fn($a,$b) => $a[2] <=> $b[2]);

            // STATUS
            StatusPacket::send(
                $clientSocket,
                count($sections),
                "Receiving world data",
                $server
            );

            // STREAM FAST
            $buffer = '';
            $count  = 0;

            foreach ($sections as [$sx,$sy]) {

                $buffer .= $world->buildSectionPacket(
                    $sx,
                    $sy,
                    $secW,
                    $secH
                );

                $count++;

                // flush every 2 sections (~large burst)
                if ($count % 2 === 0) {
                    fwrite($clientSocket, $buffer);
                    $buffer = '';
                }
            }

            if ($buffer !== '') {
                fwrite($clientSocket, $buffer);
            }

            CompleteConnectionAndSpawnPacket::send(
                $clientSocket,
                $player,
                $server
            );

        } catch (\Throwable $e) {
            Logger::log("error", "Failed Packet 8: ".$e->getMessage());
        }
    }
}
