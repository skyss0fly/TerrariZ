clear
php start.php
